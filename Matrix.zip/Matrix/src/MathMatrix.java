//A program that provides many operations for matrices.
import java.util.*;
public class MathMatrix
{
    public static void read(int[][] array, int numRows, int numCols)  //Reads the data entered by the user by rows.
    {
        Scanner input = new Scanner (System.in);
        System.out.println("Enter an integer and press enter:");

        for(int i = 0; i < numRows; i++)
        {
            for(int j = 0; j < numCols; j++)
            {
                array[i][j] = input.nextInt();  //User enters integers.
            }
        }
        System.out.println("");
    }

    public static void printMatrix(int[][]array, int numRows, int numCols)  //Prints the matrix.
    {
        for(int i = 0; i < numRows; i++)
        {
            System.out.print("[");
            for(int j = 0; j < numCols; j++)
            {
                System.out.print(" " + array[i][j]);  //The integers are printed here.
            }
            System.out.println(" ]");
        }
        System.out.println("");
    }

    public static void add(int[][]array1, int[][]array2, int numRows, int numCols)  //Adds two matrices.
    {
        for(int i = 0; i < numRows; i++)
        {
            System.out.print("[");
            for(int j = 0; j < numCols; j++)
            {
                System.out.print(" " + (array1[i][j] + array2[i][j]));  //The adding of matrices.
            }
            System.out.println(" ]");
        }
        System.out.println("");
    }

    public static void scalarMultiply(int[][]array, int numRows, int numCols, int scalar)  //Muliplies scalar to each integer.
    {
        for(int i = 0; i < numRows; i++)
        {
            System.out.print("[");
            for(int j = 0; j < numCols; j++)
            {
                System.out.print(" " + (array[i][j] * scalar));  //The integers being multiplied by the scalar.
            }
            System.out.println(" ]");
        }
        System.out.println("");
    }

    public static void multiply(int[][]array1, int[][]array2, int numRows, int numCols)  //Multiplies two matrices.
    {
        int[][]array3 = new int [3][3];
        for(int i = 0; i < numRows; i++)
        {
            for(int j = 0; j < numCols-1; j++)
            {
                for(int k = 0; k < numCols; k++)
                {
                    array3[i][j] += array1[i][k] * array2[k][j];  //Array 1 and 2 being multiplied and equaling to a new array.

                }
            }
        }

        for(int i = 0; i < numRows; i++)  //Displays the final array with multiplied results.
        {
            System.out.print("[");
            for(int j = 0; j < numCols-1; j++)
            {
                System.out.print(" "+ array3[i][j]);  //New array is being displayed.
            }
            System.out.println(" ]");
        }
        System.out.println();
    }

    public static int determinant(int[][] array)  //Returns the determinant of a 2x2 and 3x3 matrix.
    {
        int answer = 0;
        if (array.length == 1)
        {
            answer = array[0][0];
            return answer;
        }

        if (array.length == 2)  //If 2x2 or 3x3
        {
            answer = array[0][0] * array[1][1] - array[0][1] * array[1][0];
            return answer;
        }

        for (int i = 0; i < array[0].length; i++)  //Shifting arrays.
        {
            int temp[][] = new int[array.length - 1][array[0].length - 1];
            for (int j = 1; j < array.length; j++)
            {
                for (int k = 0; k < array[0].length; k++)
                {
                    if (k < i)
                    {
                        temp[j - 1][k] = array[j][k];
                    }
                    else if (k > i)
                    {
                        temp[j - 1][k - 1] = array[j][k];
                    }
                }
            }
            answer += array[0][i] * Math.pow(-1, (int) i) * determinant(temp);
        }
        return answer;  //Returns determinant.
    }

    public static void main(String[] args)
    {
        Scanner input = new Scanner (System.in);

        int choice, again = 0;  //Variables to control the loops.
        int rows, cols, rows2, cols2;  //Dimensions of the table.

        System.out.println("Welcome to Array of Arrays!");
        System.out.println("Enter 1 for Addition of Matrices: ");  //Asks the user for their choice.
        System.out.println("Enter 2 for Scalar Multiplication: ");
        System.out.println("Enter 3 for Multiplication of Matrices: ");
        System.out.println("Enter 4 for Determinant: ");
        System.out.println("Enter 5 to Exit: ");
        choice = input.nextInt();
        while (choice > 5 || choice < 0)
        {
            System.out.print("Please enter a correct choice: ");
            choice = input.nextInt();
        }

        do
        {
            while (choice == 1)  //The addition matrix.
            {
                System.out.println("");

                System.out.print("How many rows are in the table: ");  //Asks for the number of rows.
                rows = input.nextInt();
                while (rows < 0)
                {
                    System.out.print("Please enter more than zero rows or you will get an undefined matrix: ");
                    rows = input.nextInt();
                }

                System.out.print("How many columns are in the table: ");  //Asks for the number of columns.
                cols = input.nextInt();
                while (cols < 0)
                {
                    System.out.print("Please enter more than zero columns or you will get an undefined matrix: ");
                    cols = input.nextInt();
                }

                System.out.println("");

                int[][]addMain1 = new int[rows][cols];  //First matrix.
                int[][]addMain2 = new int[rows][cols];  //Second matrix.

                read(addMain1, rows, cols);  //Reads integers from the user and prints the matrix.
                System.out.println("First matrix");
                printMatrix(addMain1, rows, cols);

                read(addMain2, rows, cols);  //Reads integers from the user and prints the matrix.
                System.out.println("Second matrix");
                printMatrix(addMain2, rows, cols);

                System.out.println("Total matrix");  //Adds both matrices and prints the total.
                add(addMain1, addMain2, rows, cols);

                System.out.println("Enter 1 for Addition of Matrices: ");  //Ask the user for another choice.
                System.out.println("Enter 2 for Scalar Multiplication: ");
                System.out.println("Enter 3 for Multiplication of Matrices : ");
                System.out.println("Enter 4 for Determinant: ");
                System.out.println("Enter 5 to Exit: ");
                choice = input.nextInt();
            }

            while (choice == 2)  //The scalar matrix.
            {
                System.out.println("");

                System.out.print("How many rows are in the table: ");  //Asks for the number of rows.
                rows = input.nextInt();
                while (rows < 0)
                {
                    System.out.print("Please enter more than zero rows or you will get an undefined matrix: ");
                    rows = input.nextInt();
                }

                System.out.print("How many columns are in the table: ");  //Asks for the number of columns.
                cols = input.nextInt();
                while (cols < 0)
                {
                    System.out.print("Please enter more than zero columns or you will get an undefined matrix: ");
                    cols = input.nextInt();
                }

                System.out.print("What is the scalar value: ");  //Asks for the scalar value.
                int scalar = input.nextInt();

                System.out.println("");

                int[][]scalarMain = new int[rows][cols];  //The primary matrix.

                read(scalarMain, rows, cols);  //Reads integers from the user and prints the matrix.
                System.out.println("The matrix");
                printMatrix(scalarMain, rows, cols);

                System.out.println("Scalar matrix");  //Adds both matrices and prints the total.
                scalarMultiply(scalarMain, rows, cols, scalar);

                System.out.println("Enter 1 for Addition of Matrices: ");  //Ask the user for another choice.
                System.out.println("Enter 2 for Scalar Multiplication: ");
                System.out.println("Enter 3 for Multiplication of Matrices : ");
                System.out.println("Enter 4 for Determinant: ");
                System.out.println("Enter 5 to Exit: ");
                choice = input.nextInt();
            }

            while (choice == 3)  //The multiplication matrix.
            {
                System.out.println("");

                System.out.print("How many rows are in the matrix 1: ");  //Asks for the number of rows.
                rows = input.nextInt();
                while (rows < 0)
                {
                    System.out.print("Please enter more than zero rows or you will get an undefined matrix: ");
                    rows = input.nextInt();
                }

                System.out.print("How many columns are in the matrix 1: ");  //Asks for the number of columns.
                cols = input.nextInt();
                while (cols < 0)
                {
                    System.out.print("Please enter more than zero columns or you will get an undefined matrix: ");
                    cols = input.nextInt();
                }

                System.out.println("");

                int[][]multiplyMain1 = new int[rows][cols];  //First matrix.

                System.out.println("");

                System.out.print("How many rows are in the matrix 2: ");  //Asks for the number of rows.
                rows2 = input.nextInt();
                while (rows2 < 0)
                {
                    System.out.print("Please enter more than zero rows or you will get an undefined matrix: ");
                    rows2 = input.nextInt();
                }

                System.out.print("How many columns are in the matrix 2: ");  //Asks for the number of columns.
                cols2 = input.nextInt();
                while (cols2 != rows)
                {
                    System.out.print("The columns of the second matrix must equal the rows of the first matrix: ");
                    cols2 = input.nextInt();
                }

                System.out.println("");

                int[][]multiplyMain2 = new int[rows2][cols2];  //Second matrix.

                read(multiplyMain1, rows, cols);  //Reads integers from the user and prints the matrix.
                System.out.println("First matrix");
                printMatrix(multiplyMain1, rows, cols);

                read(multiplyMain2, rows2, cols2);  //Reads integers from the user and prints the matrix.
                System.out.println("Second matrix");
                printMatrix(multiplyMain2, rows2, cols2);

                System.out.println("Multiplied matrix");  //Multiple of both matrices and prints the total.
                multiply(multiplyMain1, multiplyMain2, rows, cols);

                System.out.println("Enter 1 for Addition of Matrices: ");  //Ask the user for another choice.
                System.out.println("Enter 2 for Scalar Multiplication: ");
                System.out.println("Enter 3 for Multiplication of Matrices : ");
                System.out.println("Enter 4 for Determinant: ");
                System.out.println("Enter 5 to Exit: ");
                choice = input.nextInt();
            }

            while (choice == 4)  //The determinant matrix.
            {
                System.out.print("Press 1 for 2x2 matrix or 2 for 3x3: ");
                int by = input.nextInt();
                while (by > 3 && by < 0)
                {
                    System.out.print("Please press 1 for 2x2 matrix or 2 for 3x3: ");
                    by = input.nextInt();
                }

                if (by == 1)
                {
                    System.out.println("");

                    System.out.print("How many rows are in the table: ");  //Asks for the number of rows.
                    rows = input.nextInt();
                    while (rows != 2)
                    {
                        System.out.print("Please enter 2 rows for 2x2 matrix: ");
                        rows = input.nextInt();
                    }

                    System.out.print("How many columns are in the table: ");  //Asks for the number of columns.
                    cols = input.nextInt();
                    while (cols != 2)
                    {
                        System.out.print("Please enter 2 columns for 2x2 matrix: ");
                        cols = input.nextInt();
                    }

                    System.out.println("");

                    int[][]deterMain = new int[rows][cols];  //The primary matrix.

                    read(deterMain, rows, cols);  //Reads integers from the user and prints the matrix.
                    System.out.println("The matrix");
                    printMatrix(deterMain, rows, cols);

                    int answer = determinant(deterMain);
                    System.out.println("The determinant is " + answer + ".");  //Displays the determinant.

                    System.out.println("Enter 1 for Addition of Matrices: ");  //Ask the user for another choice.
                    System.out.println("Enter 2 for Scalar Multiplication: ");
                    System.out.println("Enter 3 for Multiplication of Matrices : ");
                    System.out.println("Enter 4 for Determinant: ");
                    System.out.println("Enter 5 to Exit: ");
                    choice = input.nextInt();
                }

                if (by == 2)
                {
                    System.out.println("");

                    System.out.print("How many rows are in the table: ");  //Asks for the number of rows.
                    rows = input.nextInt();
                    while (rows != 3)
                    {
                        System.out.print("Please enter 3 rows for 3x3 matrix: ");
                        rows = input.nextInt();
                    }

                    System.out.print("How many columns are in the table: ");  //Asks for the number of columns.
                    cols = input.nextInt();
                    while (cols != 3)
                    {
                        System.out.print("Please enter 3 columns for 3x3 matrix: ");
                        cols = input.nextInt();
                    }

                    System.out.println("");

                    int[][]deterMain = new int[rows][cols];  //The primary matrix.

                    read(deterMain, rows, cols);  //Reads integers from the user and prints the matrix.
                    System.out.println("The matrix");
                    printMatrix(deterMain, rows, cols);

                    int answer = determinant(deterMain);
                    System.out.println("The determinant is " + answer + ".");  //Displays the determinant.

                    System.out.println("Enter 1 for Addition of Matrices: ");  //Ask the user for another choice.
                    System.out.println("Enter 2 for Scalar Multiplication: ");
                    System.out.println("Enter 3 for Multiplication of Matrices : ");
                    System.out.println("Enter 4 for Determinant: ");
                    System.out.println("Enter 5 to Exit: ");
                    choice = input.nextInt();
                }
            }
        }while (choice != 5);  //Exit program.
    }


}
